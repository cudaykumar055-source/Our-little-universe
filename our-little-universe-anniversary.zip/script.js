
// Soft original synthesized melody: no copyrighted recording is bundled.
// Browsers require a user tap before audio can start.
let ctx=null, timer=null, noteIndex=0, musicOn=false;
const notes=[523.25,659.25,783.99,659.25,587.33,698.46,783.99,698.46,523.25,659.25,880,783.99,698.46,659.25,587.33,523.25];
function playNote(){
 if(!ctx||!musicOn)return;
 const now=ctx.currentTime, freq=notes[noteIndex++%notes.length];
 const osc=ctx.createOscillator(), gain=ctx.createGain();
 osc.type='sine';osc.frequency.value=freq;gain.gain.setValueAtTime(.0001,now);gain.gain.exponentialRampToValueAtTime(.055,now+.08);gain.gain.exponentialRampToValueAtTime(.0001,now+.75);
 osc.connect(gain);gain.connect(ctx.destination);osc.start(now);osc.stop(now+.8);
}
function toggleMusic(){
 const btn=document.getElementById('musicToggle');
 if(!musicOn){ctx=ctx||new (window.AudioContext||window.webkitAudioContext)();ctx.resume();musicOn=true;playNote();timer=setInterval(playNote,650);btn.textContent='♫ Music on';}
 else{musicOn=false;clearInterval(timer);btn.textContent='♫ Play music';}
}
document.addEventListener('DOMContentLoaded',()=>{
 const b=document.getElementById('musicToggle');if(b)b.addEventListener('click',toggleMusic);
 const obs=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('show');obs.unobserve(e.target)}}),{threshold:.1});
 document.querySelectorAll('.reveal').forEach(x=>obs.observe(x));
 document.querySelectorAll('[data-photo-slot]').forEach((slot)=>{
  const input=slot.querySelector('input'), img=slot.querySelector('img'), placeholder=slot.querySelector('.placeholder');
  if(input)input.addEventListener('change',e=>{const f=e.target.files[0];if(f){img.src=URL.createObjectURL(f);img.hidden=false;placeholder.hidden=true;}});
 });
 document.querySelectorAll('.reason').forEach(el=>el.addEventListener('click',()=>el.classList.toggle('flipped')));
});
